﻿using System.ComponentModel;
using System.Configuration.Install;
using System.ServiceProcess;

namespace ItantProcessor
{
    [RunInstaller(true)]
    public partial class ProjectInstaller : Installer
    {
        public ProjectInstaller()
        {
            InitializeComponent();
            this.BeforeUninstall += new InstallEventHandler(serviceProcessInstaller1_BeforeUninstall);
            this.AfterInstall += new InstallEventHandler(serviceProcessInstaller1_AfterInstall);

        }

        private void serviceProcessInstaller1_BeforeUninstall(object sender, InstallEventArgs e)
        {
            using (ServiceController sc = new ServiceController("ItantaProcessor"))
            {
                sc.Stop();
            }
        }

        private void serviceProcessInstaller1_AfterInstall(object sender, InstallEventArgs e)
        {
            using (ServiceController sc = new ServiceController("ItantaProcessor"))
            {
                sc.Start();
            }
        }

        private void serviceProcessInstaller1_AfterInstall_1(object sender, InstallEventArgs e)
        {

        }

        private void ItantaProcessor_AfterInstall(object sender, InstallEventArgs e)
        {

        }
    }
}
